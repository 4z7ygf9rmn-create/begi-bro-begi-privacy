import os
import re
import glob
from PIL import Image, ImageOps

ROOT = os.getcwd()
ANDROID_DIR = os.path.join(ROOT, "android")
APP_DIR = os.path.join(ANDROID_DIR, "app")
RES_DIR = os.path.join(APP_DIR, "src", "main", "res")
OUT_STORE_DIR = os.path.join(ROOT, "store-assets")
os.makedirs(OUT_STORE_DIR, exist_ok=True)

VERSION_CODE = int(os.environ.get("VERSION_CODE", "1") or "1")
VERSION_NAME = os.environ.get("VERSION_NAME", "1.0.0") or "1.0.0"
TARGET_SDK = int(os.environ.get("TARGET_SDK", "35") or "35")

def find_first(patterns):
    for pat in patterns:
        matches = sorted(glob.glob(os.path.join(ROOT, pat)))
        if matches:
            return matches[0]
    return None

# 1. Resolve app icon (user-uploaded icon.png/jpg takes priority over default-icon.png)
icon_src = find_first([
    "icon.png", "icon.jpg", "icon.jpeg", "icon.webp",
    "Icon.png", "Icon.jpg", "Icon.jpeg",
    "assets/icon.png", "assets/icon.jpg",
    "assets/default-icon.png"
])
assert icon_src and os.path.exists(icon_src), "No icon source found!"
print(f"[prepare_android] Using icon source: {icon_src}")

im_icon = Image.open(icon_src).convert("RGBA")
im_512 = ImageOps.fit(im_icon, (512, 512), method=Image.Resampling.LANCZOS)
im_512.save(os.path.join(OUT_STORE_DIR, "play-store-icon-512x512.png"), "PNG")
print("[prepare_android] Saved store-assets/play-store-icon-512x512.png")

# 2. Optional banner -> exact Google Play 1024x500 Feature Graphic
banner_src = find_first([
    "banner.png", "banner.jpg", "banner.jpeg", "banner.webp",
    "Banner.png", "Banner.jpg", "Banner.jpeg",
    "feature.png", "feature.jpg", "assets/banner.png", "assets/banner.jpg"
])
if banner_src and os.path.exists(banner_src):
    im_ban = Image.open(banner_src).convert("RGB")
    im_1024 = ImageOps.fit(im_ban, (1024, 500), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
    im_1024.save(os.path.join(OUT_STORE_DIR, "play-store-banner-1024x500.png"), "PNG")
    print(f"[prepare_android] Saved store-assets/play-store-banner-1024x500.png from {banner_src}")

# 3. Generate all Android mipmap icons (legacy, round, adaptive foreground)
mipmap_sizes = {
    "mipmap-mdpi": (48, 108),
    "mipmap-hdpi": (72, 162),
    "mipmap-xhdpi": (96, 216),
    "mipmap-xxhdpi": (144, 324),
    "mipmap-xxxhdpi": (192, 432),
}

for folder, (sz, fg_sz) in mipmap_sizes.items():
    out_dir = os.path.join(RES_DIR, folder)
    os.makedirs(out_dir, exist_ok=True)
    im_legacy = im_512.resize((sz, sz), Image.Resampling.LANCZOS)
    im_legacy.save(os.path.join(out_dir, "ic_launcher.png"), "PNG")
    im_legacy.save(os.path.join(out_dir, "ic_launcher_round.png"), "PNG")

    canvas = Image.new("RGBA", (fg_sz, fg_sz), (0, 0, 0, 0))
    inner = int(fg_sz * 0.72)
    im_inner = im_512.resize((inner, inner), Image.Resampling.LANCZOS)
    off = (fg_sz - inner) // 2
    canvas.paste(im_inner, (off, off), im_inner)
    canvas.save(os.path.join(out_dir, "ic_launcher_foreground.png"), "PNG")

bg_xml = os.path.join(RES_DIR, "values", "ic_launcher_background.xml")
os.makedirs(os.path.dirname(bg_xml), exist_ok=True)
with open(bg_xml, "w", encoding="utf-8") as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#070b16</color>\n</resources>\n')
print("[prepare_android] Generated Android mipmap launcher icons")

# 4. Patch AndroidManifest.xml (portrait lock, VIBRATE permission, HTTPS only)
manifest_path = os.path.join(APP_DIR, "src", "main", "AndroidManifest.xml")
with open(manifest_path, "r", encoding="utf-8") as f:
    manifest = f.read()

if "android.permission.VIBRATE" not in manifest:
    manifest = manifest.replace(
        '<uses-permission android:name="android.permission.INTERNET" />',
        '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.VIBRATE" />'
    )

if 'android:screenOrientation=' not in manifest:
    manifest = manifest.replace(
        'android:name=".MainActivity"',
        'android:name=".MainActivity"\n            android:screenOrientation="portrait"'
    )

if 'android:usesCleartextTraffic=' not in manifest:
    manifest = manifest.replace(
        '<application',
        '<application\n        android:usesCleartextTraffic="false"',
        1
    )

with open(manifest_path, "w", encoding="utf-8") as f:
    f.write(manifest)
print("[prepare_android] Patched AndroidManifest.xml")

# 5. Patch variables.gradle (ensure compileSdk / targetSdk >= TARGET_SDK)
vars_path = os.path.join(ANDROID_DIR, "variables.gradle")
if os.path.exists(vars_path):
    with open(vars_path, "r", encoding="utf-8") as f:
        vtxt = f.read()
    vtxt = re.sub(r"compileSdkVersion\s*=\s*\d+", f"compileSdkVersion = {TARGET_SDK}", vtxt)
    vtxt = re.sub(r"targetSdkVersion\s*=\s*\d+", f"targetSdkVersion = {TARGET_SDK}", vtxt)
    with open(vars_path, "w", encoding="utf-8") as f:
        f.write(vtxt)
    print(f"[prepare_android] Set compileSdk/targetSdk = {TARGET_SDK} in variables.gradle")

# 6. Patch android/app/build.gradle (versionCode, versionName, release signingConfigs)
gradle_path = os.path.join(APP_DIR, "build.gradle")
with open(gradle_path, "r", encoding="utf-8") as f:
    gtxt = f.read()

gtxt = re.sub(r"versionCode\s+\d+", f"versionCode {VERSION_CODE}", gtxt)
gtxt = re.sub(r'versionName\s+"[^"]+"', f'versionName "{VERSION_NAME}"', gtxt)

signing_block = """    signingConfigs {
        release {
            def ksFile = file("upload-keystore.jks")
            if (ksFile.exists()) {
                storeFile ksFile
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS")
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {"""

if "signingConfigs {" not in gtxt:
    gtxt = gtxt.replace("    buildTypes {", signing_block, 1)
    gtxt = re.sub(
        r"(release\s*\{\s*)",
        r"\1signingConfig signingConfigs.release\n            ",
        gtxt,
        count=1
    )

with open(gradle_path, "w", encoding="utf-8") as f:
    f.write(gtxt)
print(f"[prepare_android] Patched build.gradle (versionCode={VERSION_CODE}, versionName={VERSION_NAME})")

# 7. Enhance MainActivity.java for dark bars & seamless WebAudio playback
main_act_candidates = glob.glob(os.path.join(APP_DIR, "src", "main", "java", "**", "MainActivity.java"), recursive=True)
if main_act_candidates:
    ma_path = main_act_candidates[0]
    with open(ma_path, "r", encoding="utf-8") as f:
        ma = f.read()
    pkg_match = re.search(r"package\s+([^;]+);", ma)
    pkg_name = pkg_match.group(1) if pkg_match else "com.gudratdin.begibrobegi"
    new_ma = f"""package {pkg_name};

import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebSettings;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {{
    @Override
    public void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        if (window != null) {{
            window.setStatusBarColor(Color.parseColor("#070b16"));
            window.setNavigationBarColor(Color.parseColor("#070b16"));
        }}
        if (this.bridge != null && this.bridge.getWebView() != null) {{
            WebSettings ws = this.bridge.getWebView().getSettings();
            ws.setMediaPlaybackRequiresUserGesture(false);
        }}
    }}
}}
"""
    with open(ma_path, "w", encoding="utf-8") as f:
        f.write(new_ma)
    print(f"[prepare_android] Enhanced {ma_path}")
